from django import forms
from django.forms import ModelForm
from .models import *


class TaskForm(forms.ModelForm):
    """Form definition for Task."""
    title = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Add new task...'}))
    class Meta:       
        """Meta definition for Taskform."""
        model = Task
        fields = '__all__'
